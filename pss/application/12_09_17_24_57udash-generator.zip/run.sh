#!/usr/bin/env bash
java -jar udash-generator.jar